import { useEffect, useMemo, useRef, useState } from "react";
import music from "@/assets/enchanted-library.mp3.asset.json";
import bg from "@/assets/bg-battle.jpg";
import owl from "@/assets/owl.png";
import { ELEMENTS, ENEMIES, FALLBACK, HEROES, MODES, REGIONS, type Challenge, type Element, type Mode } from "@/lib/game-data";
import { generateChallenge } from "@/lib/challenge.functions";
import { dueConcepts, loadCards, recordResult } from "@/lib/memory";
import { AURAS, DEFAULT, SPELLS, levelFromXp, loadProfile, saveProfile, starsFor, titleFor, unlockedCount, type Profile } from "@/lib/profile";
import { setSound, sfx } from "@/lib/sfx";
import { audio } from "@/lib/audio";
import { ACCESSORIES, ACHIEVEMENTS, PETS, SKILLS, checkAchievements, totalMods } from "@/lib/arcano";
import { nextQuestion, SUBJECTS } from "@/lib/questions";

type Hero = (typeof HEROES)[number];

const ALL_MODES = Object.keys(MODES) as Mode[];

function shuffle(c: Challenge): Challenge {
  const idx = c.options.map((_, i) => i).sort(() => Math.random() - 0.5);
  return { ...c, options: idx.map((i) => c.options[i]!), answerIndex: idx.indexOf(c.answerIndex) };
}

const NAV: [string, string][] = [["inicio", "🏰 Inicio"], ["mapa", "🗺️ Mapa"], ["tienda", "🎨 Tienda"], ["logros", "🏅 Logros"], ["grimorio", "📖 Grimorio"], ["ajustes", "⚙️ Ajustes"], ["ayuda", "❔ Ayuda"]];
const TEXT_PX = { sm: "14px", md: "16px", lg: "19px" } as const;

export function Game() {
  const [p, setP] = useState<Profile>(DEFAULT);
  const [stage, setStage] = useState<number | null>(null);
  const [levelUp, setLevelUp] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => { const l = loadProfile(); setP(l); setSound(l.sound); }, []);
  const update = (fn: (x: Profile) => Profile) => setP((old) => { const n = fn(old); saveProfile(n); return n; });
  const hero = HEROES.find((h) => h.id === p.heroId) ?? HEROES[0]!;
  const aura = AURAS.find((a) => a.id === p.aura)?.color ?? AURAS[0]!.color;
  const lvl = levelFromXp(p.xp).lvl;

  useEffect(() => { setSound(p.sound); }, [p.sound]);
  useEffect(() => { document.documentElement.style.fontSize = TEXT_PX[p.textSize]; }, [p.textSize]);
  // Logros: se revisan cada vez que cambia el perfil
  useEffect(() => {
    const r = checkAchievements(p);
    if (!r.unlocked.length) return;
    update((x) => checkAchievements(x).p);
    setToast(r.unlocked.map((a) => `🏅 ${a.name} (+${a.reward} 🪙)`).join("  ·  ")); sfx.win();
  }, [p]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(null), 3500); return () => clearTimeout(t); }, [toast]);

  const goTo = (id: string) => requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView({ behavior: p.motion ? "smooth" : "auto", block: "start" }));

  const finishBattle = (won: boolean, hpLeft: number, xp: number, coins: number, perfect = false) => {
    const before = levelFromXp(p.xp).lvl;
    const boss = stage !== null && ENEMIES[stage]?.boss;
    update((x) => {
      const stars = [...x.stars];
      if (won && stage !== null) stars[stage] = Math.max(stars[stage] ?? 0, starsFor(hpLeft, 100 + totalMods(x).hp));
      const st = x.stats;
      return { ...x, xp: x.xp + xp, coins: x.coins + coins, stars, stats: { ...st, battles: st.battles + 1, wins: st.wins + (won ? 1 : 0), bosses: st.bosses + (won && boss ? 1 : 0), perfects: st.perfects + (perfect ? 1 : 0) } };
    });
    const after = levelFromXp(p.xp + xp).lvl;
    if (after > before) { setLevelUp(after); sfx.win(); }
    setStage(null); goTo("mapa");
  };

  const firstTime = !p.name;
  return (
    <div className={`relative min-h-screen overflow-x-clip ${p.motion ? "" : "still-realm"}`}>
      <Ambience p={p} />
      <img src={bg} alt="" className="pointer-events-none fixed inset-0 h-full w-full object-cover opacity-40" width={1920} height={1088} />
      <Particles />
      <TopNav p={p} lvl={lvl} goTo={goTo} toggleMusic={() => update((x) => ({ ...x, music: !x.music }))} />
      <main className="relative z-10 pt-14">
        <section id="inicio" className="scroll-mt-14"><Title onStart={() => { sfx.click(); goTo(p.name ? "mapa" : "heroe"); }} returning={!!p.name} name={p.name} /></section>
        <section id="heroe" className="scroll-mt-14">
          <HeroSelect initial={p.name} onPick={(h, name) => { update((x) => ({ ...x, heroId: h.id, name })); goTo(firstTime ? "ayuda" : "mapa"); }} />
        </section>
        <section id="mapa" className="scroll-mt-14">
          {p.name ? <MapScreen p={p} hero={hero} aura={aura} onPick={(i) => { sfx.click(); setStage(i); goTo("batalla"); }} />
            : <div className="mx-auto max-w-xl px-4 py-16 text-center"><p className="parchment rounded-2xl p-6 font-title">Primero elige a tu aprendiz y ponle nombre ↑</p></div>}
        </section>
        {stage !== null && <section id="batalla" className="scroll-mt-14"><Battle key={stage} hero={hero} p={p} aura={aura} stage={stage} update={update} onExit={finishBattle} /></section>}
        <section id="tienda" className="scroll-mt-14"><Shop p={p} hero={hero} update={update} /></section>
        <section id="logros" className="scroll-mt-14"><Achievements p={p} lvl={lvl} /></section>
        <section id="grimorio" className="scroll-mt-14"><Grimoire stamp={p.stats.answers} /></section>
        <section id="ajustes" className="scroll-mt-14"><Settings p={p} update={update} /></section>
        <section id="ayuda" className="scroll-mt-14"><Tutorial onDone={() => goTo(p.name ? "mapa" : "heroe")} /></section>
        <footer className="px-4 pb-10 pt-4 text-center font-title text-xs text-muted-foreground">✦ Alquimia Mágica · Sparky + Owlbound + LevelUp ✦</footer>
      </main>
      {toast && <div className="animate-pop parchment fixed bottom-5 left-1/2 z-50 max-w-[92vw] -translate-x-1/2 rounded-2xl px-5 py-3 text-center font-title text-sm font-bold">{toast}</div>}
      {levelUp && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 px-4" onClick={() => setLevelUp(null)}>
          <div className="parchment animate-pop max-w-sm rounded-2xl p-8 text-center">
            <p className="font-title text-sm tracking-widest">¡SUBISTE DE NIVEL!</p>
            <p className="font-display text-6xl">{levelUp}</p>
            <p className="mt-2 font-title text-lg">Ahora eres: {titleFor(levelUp)}</p>
            {SKILLS.filter((k) => k.unlock === levelUp).map((k) => <p key={k.id} className="mt-1 font-bold">Nueva habilidad: {k.icon} {k.name}</p>)}
            <button className="rune-btn mt-4 px-6 py-2">¡Genial!</button>
          </div>
        </div>
      )}
    </div>
  );
}

function TopNav({ p, lvl, goTo, toggleMusic }: { p: Profile; lvl: number; goTo: (id: string) => void; toggleMusic: () => void }) {
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b-2 border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center gap-2 px-3 py-2">
        <nav className="flex min-w-0 flex-1 gap-1.5 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
          {NAV.map(([id, label]) => <button key={id} onClick={() => { sfx.click(); goTo(id); }} className="rune-btn shrink-0 px-3 py-1 text-xs sm:text-sm">{label}</button>)}
        </nav>
        <button onClick={toggleMusic} aria-label="Música" title="Música" className="rune-btn shrink-0 px-2 py-1 text-sm">{p.music ? "🎵" : "🔇"}</button>
        <p className="shrink-0 font-title text-xs font-bold sm:text-sm">🪙 {p.coins} · Nv {lvl}</p>
      </div>
    </header>
  );
}

/** Música del reino (Owlbound). Si el archivo no carga, suena la melodía mágica generada de LevelUp. */
function Ambience({ p }: { p: Profile }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    el.volume = p.volume;
    const sync = () => {
      const on = p.music && !document.hidden;
      if (failed) {
        audio.set({ musicOn: on, sfxOn: false, musicVol: Math.min(1, p.volume * 2), sfxVol: 0 });
        if (on) audio.startMusic(); else audio.stopMusic();
        return;
      }
      if (on) void el.play().catch(() => {}); else el.pause();
    };
    sync();
    document.addEventListener("pointerdown", sync); document.addEventListener("visibilitychange", sync);
    return () => { document.removeEventListener("pointerdown", sync); document.removeEventListener("visibilitychange", sync); el.pause(); audio.stopMusic(); };
  }, [p.music, p.volume, failed]);
  return <audio ref={ref} src={music.url} loop preload="auto" aria-label="Música del reino" onError={() => setFailed(true)} />;
}

function Particles() {
  const dots = useMemo(() => Array.from({ length: 22 }, (_, i) => ({ left: (i * 37) % 100, size: 3 + (i % 4) * 2, dur: 9 + (i % 7) * 2, delay: -(i * 1.3) })), []);
  return (
    <div className="pointer-events-none fixed inset-0 z-0" aria-hidden>
      {dots.map((d, i) => (
        <span key={i} className="animate-drift absolute bottom-0 rounded-full bg-primary blur-[1px]"
          style={{ left: `${d.left}%`, width: d.size, height: d.size, animationDuration: `${d.dur}s`, animationDelay: `${d.delay}s` }} />
      ))}
    </div>
  );
}

function Title({ onStart, returning, name }: { onStart: () => void; returning: boolean; name: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 px-4 text-center">
      <img src={owl} alt="Búho Sabio" className="w-40 animate-float sm:w-56" width={1024} height={1024} />
      <p className="font-title tracking-[0.3em] text-primary">✦ UN REINO DE HECHIZOS PERDIDOS ✦</p>
      <h1 className="font-display text-4xl leading-tight glow-text sm:text-6xl">Alquimia Mágica</h1>
      <h2 className="font-title text-lg text-muted-foreground sm:text-2xl">La Batalla de los Elementos Perdidos</h2>
      <button onClick={onStart} className="rune-btn mt-4 animate-pop px-10 py-4 text-xl">{returning ? `Continuar, ${name}` : "Comenzar aventura"}</button>
      <p className="max-w-md text-sm text-muted-foreground">9 monstruos · 5 elementos · 8 tipos de retos · 8 materias · 10 habilidades · 30 logros · un Oráculo que nunca repite pergaminos.</p>
      <p className="max-w-md text-sm italic text-muted-foreground">El reino ha perdido sus recuerdos. Aurora y Teo necesitan tu magia.</p>
    </div>
  );
}

function HeroSelect({ onPick, initial }: { onPick: (h: Hero, name: string) => void; initial: string }) {
  const [name, setName] = useState(initial);
  const [sel, setSel] = useState<Hero>(HEROES[0]!);
  return (
    <div className="mx-auto flex max-w-5xl flex-col items-center justify-center gap-5 px-4 py-16">
      <h2 className="font-display text-3xl glow-text sm:text-4xl">Elige tu aprendiz</h2>
      <div className="grid w-full gap-6 sm:grid-cols-2">
        {HEROES.map((h) => (
          <button key={h.id} onClick={() => { sfx.click(); setSel(h); }} className={`group rounded-2xl border-2 bg-card p-4 text-left transition hover:border-primary ${sel.id === h.id ? "border-primary shadow-[var(--shadow-glow)]" : "border-border"}`}>
            <img src={h.img} alt={h.name} className="mx-auto h-60 object-contain transition group-hover:scale-105 sm:h-80" width={1024} height={1024} />
            <p className="font-display text-2xl text-primary">{h.name}</p>
            <p className="font-title text-sm text-muted-foreground">{h.title}</p>
            <p className="mt-2 italic">“{h.line}”</p>
          </button>
        ))}
      </div>
      <div className="flex w-full max-w-md flex-col gap-2 sm:flex-row">
        <input value={name} onChange={(e) => setName(e.target.value.slice(0, 16))} placeholder="Tu nombre de mago"
          className="flex-1 rounded-xl border-2 border-border bg-card px-4 py-3 font-title outline-none focus:border-primary" />
        <button disabled={!name.trim()} onClick={() => onPick(sel, name.trim())} className="rune-btn px-6 py-3 disabled:opacity-50">¡Listo!</button>
      </div>
    </div>
  );
}

const TUTORIAL = [
  "¡Hola, aprendiz! Soy Ulises, el búho del reino. Los hechizos se descontrolaron porque la gente olvidó cómo organizar la información.",
  "Tienes 5 elementos: 🔥 Inquisición, 💧 Bogotazo, ⚡ técnicas de estudio, 🌿 historia de Colombia y 🌑 lectura crítica.",
  "El Oráculo te dará retos de 8 tipos: idea clave, dato falso, causa y efecto, orden de hechos, vocabulario, inferencia, hecho u opinión y completar.",
  "Responde rápido para un ⚡GOLPE CRÍTICO y encadena aciertos para hacer COMBOS. ¡Usa el elemento débil del monstruo para daño doble!",
  "Lo que olvides volverá más adelante. Si lo aciertas, ganas un 🛡️ Escudo de Memoria. Gana XP, sube de nivel y gasta monedas en la tienda de auras y hechizos.",
  "Cada acierto te da 💧 maná para usar HABILIDADES (50/50, pista, escudo, curación...) que se desbloquean al subir de nivel. Las mascotas y accesorios de la tienda te dan bonos, y los 🏅 logros te regalan monedas.",
];

function Tutorial({ onDone }: { onDone: () => void }) {
  const [i, setI] = useState(0);
  return (
    <div className="flex min-h-[80vh] items-end justify-center px-4 pb-10 sm:items-center">
      <div className="flex w-full max-w-3xl flex-col items-center gap-4 sm:flex-row sm:items-end">
        <img src={owl} alt="Ulises el búho" className="w-36 shrink-0 animate-float sm:w-52" width={1024} height={1024} />
        <div key={i} className="parchment animate-pop relative w-full rounded-2xl p-6">
          <p className="font-title text-sm font-bold">Ulises · {i + 1}/{TUTORIAL.length}</p>
          <p className="mt-2 text-lg leading-relaxed">{TUTORIAL[i]}</p>
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={onDone} className="px-3 text-sm underline">Saltar</button>
            <button onClick={() => { sfx.click(); if (i < TUTORIAL.length - 1) setI(i + 1); else { setI(0); onDone(); } }} className="rune-btn px-6 py-2">
              {i < TUTORIAL.length - 1 ? "Siguiente" : "¡A luchar!"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function HeroAvatar({ hero, aura, size = "h-16 w-16" }: { hero: Hero; aura: string; size?: string }) {
  return <img src={hero.img} alt="" className={`${size} shrink-0 rounded-full border-2 bg-card object-cover object-top`} style={{ borderColor: aura, boxShadow: `0 0 18px ${aura}` }} width={64} height={64} />;
}

function MapScreen({ p, hero, aura, onPick }: { p: Profile; hero: Hero; aura: string; onPick: (i: number) => void }) {
  const lv = levelFromXp(p.xp);
  const unlocked = unlockedCount(p.stars, ENEMIES.length);
  const totalStars = p.stars.reduce((a, b) => a + (b ?? 0), 0);
  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <header className="parchment grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl p-3">
        <div className="flex min-w-0 items-center gap-3">
          <HeroAvatar hero={hero} aura={aura} />
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-lg">{p.name} · Nv {lv.lvl}</p>
            <p className="truncate font-title text-xs">{titleFor(lv.lvl)}</p>
            <div className="mt-1 h-2 w-full max-w-48 overflow-hidden rounded-full bg-muted">
              <div className="h-full bg-primary transition-all" style={{ width: `${(lv.into / lv.need) * 100}%` }} />
            </div>
          </div>
        </div>
        <div className="text-right font-title text-sm font-bold">
          <p>🪙 {p.coins}</p>
          <p>⭐ {totalStars}/{ENEMIES.length * 3}</p>
        </div>
      </header>

      {REGIONS.map((r, ri) => (
        <section key={r.name} className="mt-6">
          <h2 className="font-display text-2xl glow-text">{r.name}</h2>
          <p className="text-sm text-muted-foreground">{r.desc}</p>
          <div className="mt-3 grid grid-cols-3 gap-3">
            {ENEMIES.map((e, i) => ({ e, i })).filter(({ e }) => e.region === ri).map(({ e, i }) => {
              const locked = i >= unlocked;
              const st = p.stars[i] ?? 0;
              return (
                <button key={e.id} disabled={locked} onClick={() => onPick(i)}
                  className={`relative rounded-2xl border-2 bg-card p-2 text-center transition enabled:hover:-translate-y-1 enabled:hover:border-primary disabled:opacity-50 sm:p-3 ${i === unlocked - 1 && !st ? "border-primary shadow-[var(--shadow-glow)]" : "border-border"}`}>
                  {e.boss && <span className="absolute right-2 top-2 rounded-full bg-destructive px-2 text-xs font-bold text-destructive-foreground">JEFE</span>}
                  <p className="font-title text-xs text-muted-foreground">Nivel {i + 1}</p>
                  <img src={e.img} alt={e.name} style={{ filter: locked ? "grayscale(1) brightness(.5)" : e.tint || undefined }} className={`mx-auto h-24 object-contain sm:h-36 ${i === unlocked - 1 ? "animate-float" : ""}`} width={1024} height={1024} loading="lazy" />
                  <p className="font-title text-xs font-bold sm:text-sm">{locked ? "🔒" : e.name}</p>
                  {!locked && <p className="text-xs">{"⭐".repeat(st)}{"☆".repeat(3 - st)}</p>}
                </button>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}

function Shop({ p, hero, update }: { p: Profile; hero: Hero; update: (fn: (x: Profile) => Profile) => void }) {
  const buy = (id: string, price: number, kind: "aura" | "spell" | "pet" | "accessory") => {
    if (price === 0 || p.owned.includes(id)) { sfx.click(); update((x) => ({ ...x, [kind]: id })); return; }
    if (p.coins < price) { sfx.bad(); return; }
    sfx.coin();
    update((x) => ({ ...x, coins: x.coins - price, owned: [...x.owned, id], [kind]: id }));
  };
  const aura = AURAS.find((a) => a.id === p.aura)!.color;
  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <div className="flex items-center justify-end">
        <p className="font-title font-bold">🪙 {p.coins}</p>
      </div>
      <h2 className="mt-2 text-center font-display text-3xl glow-text">Tienda del Alquimista</h2>
      <div className="relative mx-auto mt-2 grid h-56 w-56 place-items-center">
        <div className="animate-aura absolute inset-6 rounded-full blur-2xl" style={{ background: aura }} />
        <img src={hero.img} alt={hero.name} className="relative h-56 animate-float object-contain" width={1024} height={1024} />
        {p.accessory !== "none" && <span className="absolute right-2 top-2 text-4xl drop-shadow">{ACCESSORIES.find((x) => x.id === p.accessory)?.emoji}</span>}
        {p.pet !== "none" && <span className="absolute bottom-2 left-0 text-4xl drop-shadow">{PETS.find((x) => x.id === p.pet)?.emoji}</span>}
      </div>
      <div className="mt-3 flex justify-center gap-2">
        {HEROES.map((h) => (
          <button key={h.id} onClick={() => update((x) => ({ ...x, heroId: h.id }))} className={`rune-btn px-4 py-1 text-sm ${p.heroId === h.id ? "" : "opacity-60"}`}>{h.name}</button>
        ))}
      </div>
      <h3 className="mt-6 font-title text-xl font-bold">Auras</h3>
      <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {AURAS.map((a) => (
          <button key={a.id} onClick={() => buy(a.id, a.price, "aura")} className={`flex items-center gap-3 rounded-xl border-2 bg-card p-3 text-left ${p.aura === a.id ? "border-primary" : "border-border"}`}>
            <span className="h-8 w-8 shrink-0 rounded-full" style={{ background: a.color, boxShadow: `0 0 14px ${a.color}` }} />
            <span className="min-w-0 text-sm"><b className="block truncate">{a.name}</b>{p.owned.includes(a.id) ? (p.aura === a.id ? "Equipada" : "Equipar") : `🪙 ${a.price}`}</span>
          </button>
        ))}
      </div>
      <h3 className="mt-6 font-title text-xl font-bold">Forma del hechizo</h3>
      <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {SPELLS.map((s) => (
          <button key={s.id} onClick={() => buy(s.id, s.price, "spell")} className={`rounded-xl border-2 bg-card p-3 text-center ${p.spell === s.id ? "border-primary" : "border-border"}`}>
            <span className="block font-display text-3xl text-primary">{s.glyph}</span>
            <b className="block text-sm">{s.name}</b>
            <span className="text-xs">{p.owned.includes(s.id) ? (p.spell === s.id ? "Equipado" : "Equipar") : `🪙 ${s.price}`}</span>
          </button>
        ))}
      </div>
      <h3 className="mt-6 font-title text-xl font-bold">🐾 Mascotas</h3>
      <ItemGrid items={PETS} cur={p.pet} owned={p.owned} onBuy={(it) => buy(it.id, it.price, "pet")} />
      <h3 className="mt-6 font-title text-xl font-bold">🎒 Accesorios</h3>
      <ItemGrid items={ACCESSORIES} cur={p.accessory} owned={p.owned} onBuy={(it) => buy(it.id, it.price, "accessory")} />
      <p className="mt-6 text-center text-sm text-muted-foreground">Gana monedas acertando retos y venciendo monstruos. ¡Los jefes dan el doble!</p>
    </div>
  );
}

function ItemGrid({ items, cur, owned, onBuy }: { items: typeof PETS; cur: string; owned: string[]; onBuy: (it: (typeof PETS)[number]) => void }) {
  return (
    <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-3">
      {items.map((it) => (
        <button key={it.id} onClick={() => onBuy(it)} className={`rounded-xl border-2 bg-card p-3 text-left transition hover:border-primary ${cur === it.id ? "border-primary shadow-[var(--shadow-glow)]" : "border-border"}`}>
          <span className="block text-3xl">{it.emoji}</span>
          <b className="block text-sm">{it.name}</b>
          <span className="block text-xs text-muted-foreground">{it.desc}</span>
          <span className="text-xs font-bold text-primary">{cur === it.id ? "Equipado" : it.price === 0 || owned.includes(it.id) ? "Equipar" : `🪙 ${it.price}`}</span>
        </button>
      ))}
    </div>
  );
}

function Achievements({ p, lvl }: { p: Profile; lvl: number }) {
  const st = p.stats;
  const acc = st.correct + st.wrong ? Math.round((st.correct / (st.correct + st.wrong)) * 100) : 0;
  const stats: [string, string | number][] = [["✅ Correctas", st.correct], ["❌ Falladas", st.wrong], ["🎯 Precisión", `${acc}%`], ["⚔️ Victorias", st.wins], ["🔥 Mejor combo", st.bestCombo], ["👑 Jefes", st.bosses], ["💯 Perfectas", st.perfects], ["🪄 Habilidades", st.skillsUsed]];
  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h2 className="text-center font-display text-3xl glow-text">Logros y Habilidades</h2>
      <p className="text-center text-sm text-muted-foreground">{p.ach.length}/{ACHIEVEMENTS.length} logros · Nivel {lvl} · {titleFor(lvl)}</p>
      <div className="parchment mt-4 grid grid-cols-2 gap-2 rounded-2xl p-4 text-sm sm:grid-cols-4">
        {stats.map(([k, v]) => <p key={k}>{k}: <b>{v}</b></p>)}
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {ACHIEVEMENTS.map((a) => {
          const ok = p.ach.includes(a.id);
          return (
            <div key={a.id} className={`flex items-center gap-3 rounded-xl border-2 bg-card p-3 ${ok ? "border-primary shadow-[var(--shadow-glow)]" : "border-border opacity-60"}`}>
              <span className="text-3xl">{ok ? a.icon : "🔒"}</span>
              <span className="min-w-0 text-sm"><b className="block font-title">{a.name}</b>{a.desc} · +{a.reward} 🪙</span>
            </div>
          );
        })}
      </div>
      <h3 className="mt-8 font-title text-xl font-bold">🪄 Habilidades de batalla</h3>
      <p className="text-sm text-muted-foreground">Cada acierto da 1 💧 de maná. Se desbloquean al subir de nivel.</p>
      <div className="mt-2 grid gap-3 sm:grid-cols-2">
        {SKILLS.map((k) => (
          <div key={k.id} className={`flex items-center gap-3 rounded-xl border-2 border-border bg-card p-3 ${lvl < k.unlock ? "opacity-50" : ""}`}>
            <span className="text-3xl">{lvl >= k.unlock ? k.icon : "🔒"}</span>
            <span className="text-sm"><b className="font-title">{k.name}</b> <span className="text-primary">{k.cost}💧</span><span className="block text-xs text-muted-foreground">{k.desc} · Nivel {k.unlock}</span></span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Settings({ p, update }: { p: Profile; update: (fn: (x: Profile) => Profile) => void }) {
  const Row = ({ label, k }: { label: string; k: "music" | "sound" | "timer" | "explain" | "motion" }) => (
    <label className="flex items-center justify-between gap-3 py-2"><span>{label}</span>
      <input type="checkbox" className="h-5 w-5" checked={p[k]} onChange={(e) => update((x) => ({ ...x, [k]: e.target.checked }))} /></label>
  );
  const reset = () => {
    if (!confirm("¿Borrar todo tu progreso? No se puede deshacer.")) return;
    ["alquimia-perfil-v2", "alquimia-memoria-v1", "alquimia-turno", "alquimia-banco-visto"].forEach((k) => localStorage.removeItem(k));
    location.reload();
  };
  return (
    <div className="mx-auto max-w-xl px-4 py-10">
      <h2 className="text-center font-display text-3xl glow-text">Ajustes del reino</h2>
      <div className="parchment mt-4 rounded-2xl p-5">
        <Row label="🎵 Música de fondo" k="music" />
        <label className="flex items-center justify-between gap-3 py-2"><span>Volumen {Math.round(p.volume * 100)}%</span>
          <input aria-label="Volumen de música" type="range" min="0" max="1" step="0.05" value={p.volume} onChange={(e) => update((x) => ({ ...x, volume: Number(e.target.value) }))} /></label>
        <Row label="🔊 Efectos de sonido" k="sound" />
        <Row label="⏳ Reloj en cada reto" k="timer" />
        <Row label="💡 Mostrar explicaciones" k="explain" />
        <Row label="✨ Animaciones" k="motion" />
        <div className="flex items-center justify-between gap-3 py-2"><span>🔠 Tamaño del texto</span>
          <div className="flex gap-1">{(["sm", "md", "lg"] as const).map((t) => <button key={t} onClick={() => update((x) => ({ ...x, textSize: t }))} className={`rune-btn px-3 py-1 text-sm ${p.textSize === t ? "" : "opacity-60"}`}>{t === "sm" ? "A-" : t === "md" ? "A" : "A+"}</button>)}</div></div>
        <label className="block py-2">Nombre del aprendiz
          <input maxLength={16} value={p.name} onChange={(e) => update((x) => ({ ...x, name: e.target.value }))} className="mt-1 w-full rounded-xl border-2 border-border bg-card px-3 py-2 font-title outline-none focus:border-primary" /></label>
      </div>
      <div className="mt-4 text-center"><button onClick={reset} className="text-sm text-destructive underline">🗑️ Reiniciar partida</button></div>
    </div>
  );
}

function Grimoire({ stamp }: { stamp: number }) {
  const cards = useMemo(() => loadCards(), [stamp]);
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h2 className="text-center font-display text-3xl glow-text">Grimorio de la Memoria</h2>
      <p className="text-center text-sm text-muted-foreground">Todo lo que has aprendido. Los conceptos con pocas runas volverán en batalla.</p>
      {cards.length === 0 && <p className="parchment mt-6 rounded-2xl p-6 text-center">Aún está vacío. ¡Ve a luchar y llénalo!</p>}
      <div className="mt-4 grid gap-3">
        {cards.map((c) => (
          <div key={c.concept} className="parchment rounded-xl p-4">
            <div className="flex items-center justify-between gap-2">
              <b className="font-title">{c.concept}</b>
              <span title="Dominio">{"ᚱ".repeat(c.box)}<span className="opacity-30">{"ᚱ".repeat(5 - c.box)}</span></span>
            </div>
            <p className="mt-1 text-sm">{c.explanation}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function Bar({ value, max, color }: { value: number; max: number; color: string }) {
  return (
    <div className="h-4 w-full overflow-hidden rounded-full border border-border bg-muted">
      <div className={`h-full ${color} transition-all duration-500`} style={{ width: `${Math.max(0, (value / max) * 100)}%` }} />
    </div>
  );
}

const ELEMENT_BG: Record<Element, string> = { fuego: "bg-fire", agua: "bg-water", rayo: "bg-bolt", tierra: "bg-earth", sombra: "bg-shadow" };
const TEXT_EL: Record<Element, string> = { fuego: "text-fire", agua: "text-water", rayo: "text-bolt", tierra: "text-earth", sombra: "text-shadow" };
const seenKey = "alquimia-banco-visto";
/** Pregunta del banco de LevelUp (8 materias, 3 dificultades), sin repetir. */
function bankChallenge(level: number, el: Element): Challenge {
  let seen = new Set<string>();
  try { seen = new Set(JSON.parse(localStorage.getItem(seenKey) || "[]")); } catch { /* vacío */ }
  const q = nextQuestion({ level, seen, session: new Set() });
  try { localStorage.setItem(seenKey, JSON.stringify([...seen, q.id].slice(-600))); } catch { /* sin guardado */ }
  const label = `${SUBJECTS[q.s].icon} ${SUBJECTS[q.s].label}`;
  return { element: el, source: "libro", mode: label as Mode, title: label, text: "Responde con calma: cada acierto carga tu hechizo.", question: q.q, options: q.options, answerIndex: q.answer, concept: q.q.slice(0, 80), explanation: q.e, subject: q.s };
}

function Battle({ hero, p, aura, stage, update, onExit }: { hero: Hero; p: Profile; aura: string; stage: number; update: (fn: (x: Profile) => Profile) => void; onExit: (won: boolean, hp: number, xp: number, coins: number, perfect?: boolean) => void }) {
  const enemy = ENEMIES[stage]!;
  const mods = useMemo(() => totalMods(p), []); // eslint-disable-line react-hooks/exhaustive-deps
  const lvl = levelFromXp(p.xp).lvl;
  const MAXHP = 100 + mods.hp;
  const TIME = 40 + mods.time;
  const glyph = SPELLS.find((s) => s.id === p.spell)?.glyph ?? "✦";
  const [hp, setHp] = useState(MAXHP);
  const [ehp, setEhp] = useState(enemy.hp);
  const [shield, setShield] = useState(mods.forgive);
  const [mana, setMana] = useState(2 + mods.mana);
  const [hidden, setHidden] = useState<number[]>([]);
  const [fxs, setFxs] = useState({ dbl: false, drain: false, frozen: false });
  const wrongs = useRef(0);
  const [combo, setCombo] = useState(0);
  const [phase, setPhase] = useState<"intro" | "choose" | "loading" | "read" | "result" | "end">("intro");
  const [ch, setCh] = useState<Challenge | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [msg, setMsg] = useState("");
  const [fx, setFx] = useState<{ who: "hero" | "enemy"; text: string; k: number } | null>(null);
  const [shot, setShot] = useState<{ el: Element; k: number } | null>(null);
  const [left, setLeft] = useState(TIME);
  const earned = useRef({ xp: 0, coins: 0 });
  const turn = useRef(0);
  const used = useRef<string[]>([]);
  const modeIdx = useRef(Math.floor(Math.random() * ALL_MODES.length));
  const started = useRef(0);
  const enraged = enemy.boss && ehp <= enemy.hp / 2;

  useEffect(() => { turn.current = Number(localStorage.getItem("alquimia-turno") || "0"); }, []);
  useEffect(() => {
    if (!p.timer || fxs.frozen || phase !== "read" || picked !== null) return;
    const t = setInterval(() => setLeft((l) => Math.max(0, l - 1)), 1000);
    return () => clearInterval(t);
  }, [phase, picked, p.timer, fxs.frozen]);
  useEffect(() => { if (p.timer && phase === "read" && left === 0 && picked === null) answer(-1); }, [left]); // eslint-disable-line react-hooks/exhaustive-deps

  const cast = async (el: Element) => {
    sfx.cast();
    setPhase("loading");
    setPicked(null); setHidden([]); setFxs((f) => ({ ...f, frozen: false }));
    const mode = ALL_MODES[modeIdx.current++ % ALL_MODES.length]!;
    const weak = dueConcepts(turn.current).map((c) => c.concept);
    let c: Challenge | null = Math.random() < 0.5 ? bankChallenge(5 + Math.min(stage, 8) * 6, el) : null;
    try {
      if (!c) { const r = await generateChallenge({ data: { element: el, mode, level: Math.min(10, stage + 2), weakConcepts: weak, avoid: used.current.slice(-8) } });
      c = r.challenge; }
    } catch { /* usa el libro de respaldo */ }
    if (!c) {
      const pool = FALLBACK.filter((f) => f.element === el && !used.current.includes(f.title));
      const all = FALLBACK.filter((f) => f.element === el);
      c = pool[Math.floor(Math.random() * pool.length)] ?? all[Math.floor(Math.random() * all.length)] ?? FALLBACK[0]!;
    }
    used.current.push(c.title);
    setCh(shuffle({ ...c, element: el }));
    setLeft(TIME);
    started.current = Date.now();
    setPhase("read");
  };

  const answer = (i: number) => {
    if (!ch || picked !== null) return;
    setPicked(i);
    turn.current += 1;
    localStorage.setItem("alquimia-turno", String(turn.current));
    const ok = i === ch.answerIndex;
    const secs = (Date.now() - started.current) / 1000;
    const wasWeak = loadCards().some((c) => c.concept === ch.concept && c.box < 5);
    recordResult(ch.concept, ch.explanation, ok, turn.current);
    if (!ok) wrongs.current += 1; else setMana((v) => v + 1);
    update((x) => ({ ...x, stats: { ...x.stats, answers: x.stats.answers + 1, correct: x.stats.correct + (ok ? 1 : 0), wrong: x.stats.wrong + (ok ? 0 : 1), reviews: x.stats.reviews + (ok && wasWeak ? 1 : 0), bestCombo: Math.max(x.stats.bestCombo, ok ? combo + 1 : 0), subj: ok && ch.subject ? { ...x.stats.subj, [ch.subject]: (x.stats.subj[ch.subject] ?? 0) + 1 } : x.stats.subj } }));
    if (ok) { sfx.good(); setShot({ el: ch.element!, k: Date.now() }); } else sfx.bad();
    setTimeout(() => {
      if (ok) {
        const newCombo = combo + 1;
        setCombo(newCombo);
        const weakHit = ch.element === enemy.weak;
        const crit = secs < 15;
        const dmg = Math.round((13 + Math.random() * 7) * (weakHit ? 2 : 1) * (crit ? 1.5 : 1) * (1 + Math.min(newCombo - 1, 4) * 0.1) * (1 + mods.dmg) * (fxs.dbl ? 2 : 1));
        const rest = ehp - dmg;
        setEhp(rest);
        if (fxs.dbl) setFxs((f) => ({ ...f, dbl: false }));
        if (fxs.drain) { setHp((h) => Math.min(MAXHP, h + 15)); setFxs((f) => ({ ...f, drain: false })); }
        earned.current.xp += Math.round((15 + (crit ? 5 : 0)) * (1 + mods.xp));
        earned.current.coins += Math.round((3 + Math.min(newCombo, 5)) * (1 + mods.coins));
        let m = `${ELEMENTS[ch.element!].icon} ¡Hechizo de ${ELEMENTS[ch.element!].name}! -${dmg}`;
        if (weakHit) m += " · ¡SÚPER EFECTIVO!";
        if (crit) m += " · ⚡¡CRÍTICO por rapidez!";
        if (newCombo > 1) m += ` · 🔥 Combo x${newCombo}`;
        if (wasWeak) { setShield((s) => s + 1); m += " · 🛡️ ¡Recordaste un concepto olvidado! +1 Escudo"; }
        setMsg(m);
        setFx({ who: "enemy", text: `-${dmg}`, k: Date.now() });
        if (rest <= 0) {
          earned.current.xp += enemy.boss ? 80 : 40;
          earned.current.coins += enemy.boss ? 40 : 20;
          sfx.win(); setPhase("end"); return;
        }
      } else {
        setCombo(0);
        earned.current.xp += 4;
        const atk = Math.round(enemy.atk * (enraged ? 1.3 : 1));
        const timeout = i === -1 ? "⏳ ¡Se acabó el tiempo! " : "";
        if (shield > 0) {
          setShield((s) => s - 1);
          setMsg(`${timeout}El hechizo falló... ¡pero tu 🛡️ Escudo de Memoria bloqueó el ataque!`);
          setFx({ who: "hero", text: "🛡️", k: Date.now() });
        } else {
          const rest = hp - atk;
          setHp(rest);
          setMsg(`${timeout}El hechizo se descontroló... ${enemy.name} ataca: -${atk}. Este concepto volverá pronto.`);
          setFx({ who: "hero", text: `-${atk}`, k: Date.now() });
          if (rest <= 0) { setPhase("end"); return; }
        }
      }
      setPhase("result");
    }, 750);
  };

  const won = ehp <= 0;

  const castSkill = (k: (typeof SKILLS)[number]) => {
    if (!ch || mana < k.cost || picked !== null) return;
    const wrong = ch.options.map((_, i) => i).filter((i) => i !== ch.answerIndex && !hidden.includes(i)).sort(() => Math.random() - 0.5);
    setMana((v) => v - k.cost); sfx.coin();
    update((x) => ({ ...x, stats: { ...x.stats, skillsUsed: x.stats.skillsUsed + 1 } }));
    if (k.id === "fifty") setHidden((h) => [...h, ...wrong.slice(0, 2)]);
    else if (k.id === "hint") setHidden((h) => [...h, ...wrong.slice(0, 1)]);
    else if (k.id === "oracle") setHidden((h) => [...h, ...wrong]);
    else if (k.id === "shield") setShield((v) => v + 1);
    else if (k.id === "time") setLeft((l) => l + 10);
    else if (k.id === "double") setFxs((f) => ({ ...f, dbl: true }));
    else if (k.id === "heal") setHp((h) => Math.min(MAXHP, h + 35));
    else if (k.id === "freeze") setFxs((f) => ({ ...f, frozen: true }));
    else if (k.id === "drain") setFxs((f) => ({ ...f, drain: true }));
    else if (k.id === "skip") void cast(ch.element ?? "fuego");
  };

  return (
    <div className="mx-auto flex min-h-[calc(100vh-3.5rem)] max-w-6xl flex-col px-3 py-4 sm:px-6">
      <div className="flex items-center justify-between">
        <button onClick={() => onExit(false, hp, earned.current.xp, earned.current.coins)} className="text-sm text-muted-foreground underline">← Huir</button>
        <p className="font-title text-sm text-primary">Nivel {stage + 1} · {REGIONS[enemy.region]!.name}</p>
        <p className="font-title text-sm">{combo > 1 ? `🔥 x${combo}` : ""}</p>
      </div>

      <div className="relative mt-3 grid grid-cols-2 items-end gap-2 sm:gap-8">
        <div className="relative flex flex-col items-center">
          <div className="w-full max-w-xs">
            <p className="font-title font-bold">{p.name} {shield > 0 && <span className="text-accent">🛡️×{shield}</span>}</p>
            <Bar value={hp} max={MAXHP} color="bg-hp" />
          </div>
          <div className="relative">
            <div className="animate-aura absolute inset-8 rounded-full blur-2xl" style={{ background: aura }} />
            <img src={hero.img} alt={hero.name} key={fx ? fx.k + fx.who : "h"}
              className={`relative h-44 object-contain sm:h-80 ${fx?.who === "hero" ? "animate-hit" : shot ? "animate-lunge" : "animate-float"}`} width={1024} height={1024} />
          </div>
          {fx?.who === "hero" && <span key={fx.k} className="absolute top-1/3 font-display text-4xl text-destructive animate-rise">{fx.text}</span>}
        </div>
        <div className="relative flex flex-col items-center">
          <div className="w-full max-w-xs">
            <p className="truncate font-title font-bold">{enemy.boss && "👑 "}{enemy.name} {enraged && !won && <span className="text-destructive">¡FURIOSO!</span>}</p>
            <Bar value={ehp} max={enemy.hp} color="bg-destructive" />
          </div>
          <img src={enemy.img} alt={enemy.name} key={fx?.who === "enemy" ? fx.k : "e"}
            style={{ filter: won ? "grayscale(1) opacity(.2)" : `${enemy.tint} ${enraged ? "saturate(1.8) drop-shadow(0 0 20px red)" : ""}` || undefined, ["--lunge" as string]: "-40px" }}
            className={`object-contain transition duration-1000 ${enemy.boss ? "h-52 sm:h-96" : "h-44 sm:h-80"} ${fx?.who === "enemy" ? "animate-hit" : fx?.who === "hero" ? "animate-lunge" : "animate-float"}`} width={1024} height={1024} />
          {fx?.who === "enemy" && <span key={fx.k} className="absolute top-1/3 font-display text-5xl text-primary glow-text animate-rise">{fx.text}</span>}
        </div>
        {shot && <span key={shot.k} className={`animate-fly pointer-events-none absolute left-1/4 top-1/2 font-display text-6xl ${TEXT_EL[shot.el]} glow-text`}>{glyph}</span>}
      </div>

      <div className="mt-4 flex-1">
        {phase === "intro" && <Dialog name={enemy.name} text={enemy.intro} action="¡En guardia!" onAction={() => { sfx.click(); setPhase("choose"); }} />}

        {phase === "choose" && (
          <div className="animate-pop rounded-2xl border-2 border-border bg-card p-3 sm:p-4">
            <p className="text-center font-title text-lg">Elige el elemento de tu hechizo</p>
            <p className="text-center text-xs text-muted-foreground">Próximo reto: {MODES[ALL_MODES[modeIdx.current % ALL_MODES.length]!]}</p>
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-5 sm:gap-3">
              {(Object.keys(ELEMENTS) as Element[]).map((el) => (
                <button key={el} onClick={() => cast(el)} className="rune-btn flex flex-col items-center gap-1 px-1 py-3">
                  <span className={`grid h-11 w-11 place-items-center rounded-full text-2xl ${ELEMENT_BG[el]}`}>{ELEMENTS[el].icon}</span>
                  <span className="text-sm">{ELEMENTS[el].name}</span>
                  <span className="text-[10px] font-normal leading-tight text-muted-foreground">{ELEMENTS[el].theme}</span>
                  {el === enemy.weak && <span className="text-xs text-primary">¡Débil!</span>}
                </button>
              ))}
            </div>
          </div>
        )}

        {phase === "loading" && (
          <div className="parchment flex items-center justify-center gap-4 rounded-2xl p-8">
            <img src={owl} alt="" className="h-16 w-16 animate-float" width={64} height={64} />
            <p className="font-title text-lg">El Oráculo está escribiendo tu pergamino...</p>
          </div>
        )}

        {(phase === "read" || phase === "result") && ch && (
          <div className="parchment animate-pop rounded-2xl p-4 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-title text-lg font-bold">📜 {ch.title}</p>
              <span className="rounded-full border border-current px-2 text-xs">{MODES[ch.mode] ?? ch.mode} · {ch.source === "ia" ? "Oráculo IA" : "Libro antiguo"}</span>
            </div>
            {phase === "read" && p.timer && (
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
                <div className={`h-full transition-all duration-1000 ${left > 25 ? "bg-hp" : left > 10 ? "bg-bolt" : "bg-destructive"}`} style={{ width: `${(left / TIME) * 100}%` }} />
              </div>
            )}
            <p className="mt-3 text-base leading-relaxed sm:text-lg">{ch.text}</p>
            <p className="mt-4 font-bold">{ch.question}</p>
            {phase === "read" && picked === null && (
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="font-title text-xs font-bold">💧 Maná {mana}</span>
                {SKILLS.filter((k) => lvl >= k.unlock).map((k) => (
                  <button key={k.id} disabled={mana < k.cost} onClick={() => castSkill(k)} title={k.desc} className="rounded-lg border-2 border-current px-2 py-0.5 text-xs disabled:opacity-40">{k.icon} {k.name} · {k.cost}</button>
                ))}
                {fxs.dbl && <span className="text-xs font-bold">💥 x2</span>}{fxs.drain && <span className="text-xs font-bold">🩸</span>}{fxs.frozen && <span className="text-xs font-bold">❄️</span>}
              </div>
            )}
            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              {ch.options.map((o, i) => {
                const state = picked === null ? "" : i === ch.answerIndex ? "bg-hp text-primary-foreground" : i === picked ? "bg-destructive text-destructive-foreground animate-shake" : "opacity-60";
                return (
                  <button key={i} onClick={() => answer(i)} disabled={picked !== null || hidden.includes(i)} className={`rounded-xl border-2 border-current px-3 py-2 text-left transition hover:-translate-y-0.5 ${state} ${hidden.includes(i) ? "line-through opacity-30" : ""}`}>
                    <b className="mr-1">{"ABCD"[i]}.</b> {o}
                  </button>
                );
              })}
            </div>
            {phase === "result" && (
              <div className="animate-pop mt-4 rounded-xl border-2 border-dashed border-current p-3">
                <p className="font-bold">{msg}</p>
                {p.explain && <p className="mt-1 text-sm">💡 {ch.explanation}</p>}
                <button onClick={() => { sfx.click(); setPhase("choose"); }} className="rune-btn mt-3 px-6 py-2">Siguiente turno</button>
              </div>
            )}
          </div>
        )}

        {phase === "end" && (
          <div className="parchment animate-pop rounded-2xl p-5 text-center">
            <p className="font-display text-3xl">{won ? "¡VICTORIA!" : "Derrota..."}</p>
            {won && <p className="mt-1 text-4xl">{"⭐".repeat(starsFor(hp, MAXHP))}{"☆".repeat(3 - starsFor(hp, MAXHP))}</p>}
            <p className="mt-2 text-lg">{won ? `Has vencido a ${enemy.name}. ¡El reino recupera su orden!` : "Te quedaste sin energía. Lo que fallaste quedó en tu Grimorio y volverá para que lo domines."}</p>
            <p className="mt-2 font-title font-bold">+{earned.current.xp} XP · +{earned.current.coins} 🪙</p>
            <button onClick={() => onExit(won, hp, earned.current.xp, earned.current.coins, won && wrongs.current === 0)} className="rune-btn mt-3 px-6 py-2">Volver al mapa</button>
          </div>
        )}
      </div>
    </div>
  );
}

function Dialog({ name, text, action, onAction }: { name: string; text: string; action: string; onAction: () => void }) {
  return (
    <div className="parchment animate-pop rounded-2xl p-5">
      <p className="font-display text-xl">{name}</p>
      <p className="mt-2 text-lg">{text}</p>
      <div className="mt-3 flex justify-end">
        <button onClick={onAction} className="rune-btn px-6 py-2">{action}</button>
      </div>
    </div>
  );
}
